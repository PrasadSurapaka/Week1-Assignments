package com.day2.Dec6;

import java.util.Arrays;
import java.util.List;

class Product1{
    private String name;
    private Integer id;
    private Double price;
    public Product1(String name, Integer id, Double price){
        this.name=name;
        this.id=id;
        this.price=price;
    }

    public double getPrice()
    {
        return price;
    }

    public String toString(){
        return "Product Price: "+this.name
                +"  Age: "+this.id
                +"  Salary: "+this.price;
    }
}


public class FourthAssignment {
    static List<Product1> productList = Arrays.asList(
            new Product1("Laptop", 1, 45000.00),
            new Product1("Phone", 2, 10000.00));

    public static void main(String[] args) {
        Double totalprice = productList.stream() 
                .map(tpr -> tpr.getPrice()) 
                .reduce(0.00,(a,b) -> a+b);
        
        System.out.println("Total Price: "+totalprice);
        
        Double minmumprice = productList.stream() 
                .map(mpr -> mpr.getPrice())
                .reduce(25000.00,(a,b) -> a>b?b:a );
     
        System.out.println(minmumprice);
    }
}
