package com.day2.Dec6;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FifthAssignment {

	public static void main(String[] args) {

		try {
			int id1 = 10;
			String name1 = "Hyd";
			long pincodeA = 500038L;

			FileOutputStream fos = new FileOutputStream("E:\\cities1.dat");
			DataOutputStream dos = new DataOutputStream(fos);

			dos.writeInt(id1);
			dos.writeUTF(name1);
			dos.writeLong(pincodeA);

			dos.flush();

			fos.close();
			dos.close();

			FileInputStream fis = new FileInputStream("E:\\cities1.dat");
			DataInputStream dis = new DataInputStream(fis);

			int cityId = dis.readInt();
			System.out.println("City Id: " + cityId);
			String cityName = dis.readUTF();
			System.out.println("City Name: " + cityName);

			long citypincode = dis.readLong();
			System.out.println("City pincode : " + citypincode);

			dis.close();
			fis.close();
		} catch (Exception et) {
			et.printStackTrace();
		}
	}
}
