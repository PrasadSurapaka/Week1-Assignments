package com.day2.Dec6;

	import java.util.ArrayList;
	import java.util.Collection;
	import java.util.Collections;
	import java.util.HashSet;


	class MyCustomArrayList<T> extends ArrayList<T>{
		private static final long serialVersionUID = 1L;
		
		MyCustomArrayList()
		{
		}
		
		//method to add element at the end
		private boolean addElement(T obj)
		{
			boolean added = false;

			int num_of_occurrences = Collections.frequency(this, obj);

			if(num_of_occurrences<2)
			{
				added = super.add(obj);
			}
			
			return added;		
		}
		
		//method to add element at a specific index
		private boolean addElement(int index, T obj)
		{
			boolean added = false;
			int num_of_occurrences = Collections.frequency(this, obj);

			if(num_of_occurrences<2)
			{
				super.add(index, obj);
			}
			
			return added;				
		}
		
		@Override
		public T set(int index, T obj)
		{
			int num_of_occurrences = Collections.frequency(this, obj);

			T pElement = super.get(index);
			
			if(num_of_occurrences<2)
			{			
				super.set(index, obj);
			}		
			
			return pElement;
		}
		
		@Override
		public boolean add(T obj)
		{
			return addElement(obj);
		}
		
		@Override
		public void add(int index, T obj)
		{
			addElement(obj);
		}
		
		@Override
		public boolean addAll(Collection<? extends T> coll)
		{
			boolean added_all_elements = true;
			for(T element:coll)
			{
				added_all_elements = addElement(element);
			}
			
			return added_all_elements;
		}
		
		@Override
		public boolean addAll(int index, Collection<? extends T> coll)
		{
			boolean added_all_elements = true;
			for(T element:coll)
			{
				added_all_elements = addElement(index, element);
			}
			
			return added_all_elements;
		}
	}


	public class SecondAssignment{
		
		

		public static void main(String[] args) {
			
			
			/*
			 * MyCustomArrayList<String> cArrayList = new MyCustomArrayList<String>();
			 * cArrayList.add("abc"); cArrayList.add("abc"); cArrayList.add("abc");
			 * 
			 * System.out.println(cArrayList);
			 */
			  
			
				
				  MyCustomArrayList<AnimalName> cArrayListE = new MyCustomArrayList<AnimalName>(); //cArrayListE.add("") cArrayListE.add(new
				 // EmployeeEg(1, "name1"));
				  
				  cArrayListE.add(new AnimalName("Lion1")); 
				  cArrayListE.add(new AnimalName("Lion1")); 
				  cArrayListE.add(new AnimalName("Lion1"));
				  System.out.println("AnimalName : " +cArrayListE);
				 

		}

	}


		

	class AnimalName{




	private String animalname;

	public String getAnimalname() {
		return animalname;
	}
	@Override
	public String toString() {
		return "AnimalName [animalname=" + animalname + "]";
	}
	public void setAnimalname(String animalname) {
		this.animalname = animalname;
	}
	public AnimalName(String animalname) {
		super();
		this.animalname = animalname;
	}
	//add constructor to initialize data members
	//add setter, getter methods

	@Override
	public boolean equals(Object obj) {
	if (this == obj)
	return true;
	if (obj == null)
	return false;
	if (getClass() != obj.getClass())
	return false;
	AnimalName other = (AnimalName) obj;

	if (animalname == null) {
	if (other.animalname != null)
	return false;
	} else if (!animalname.equals(other.animalname))
	return false;
	return true;
	}
	}