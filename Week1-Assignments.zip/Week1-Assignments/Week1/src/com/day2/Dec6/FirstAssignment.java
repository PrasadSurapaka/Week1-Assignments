package com.day2.Dec6;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class FirstAssignment {

	    public static void main(String[] args) {

	        ArrayList<String> emp = new ArrayList<String>();

	        emp.add("Angular");
	        emp.add("lTI");  
	        emp.add("JaVA");  
	        emp.add("SPRING");


	        TreeSet<String> ts = new TreeSet<String>(emp);
	 
	          Iterator<String> ascSorting = ts.iterator();
	        while(ascSorting.hasNext()) {
	            System.out.println(ascSorting.next());
	        }
	    }
	}