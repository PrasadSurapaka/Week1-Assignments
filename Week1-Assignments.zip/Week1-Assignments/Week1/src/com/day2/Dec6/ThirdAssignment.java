package com.day2.Dec6;

@FunctionalInterface
interface Ixyz {
	void met();
}

public class ThirdAssignment {

	public static void main(String[] args) {

		met9(() -> {
			System.out.println("Lambda Expression");
		});
	}

	static int met9(Ixyz oxyz) {
		oxyz.met();
		return 0;
	}
}