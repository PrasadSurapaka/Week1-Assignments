package com.day4.Dec8;

import java.sql.*;

public class ThirdAssignment {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection ct = DriverManager.getConnection("jdbc:mysql://localhost:3306/tweets","root","12345");
		
		
		PreparedStatement ipt = ct.prepareStatement("Insert into Twitter values (?,?,?,?)");
		ipt.setInt(1, 3);
		ipt.setString(2, "Prasad");
		ipt.setString(3, "Coocking");
		ipt.setInt(4, 200);
		
		int rst = ipt.executeUpdate();
		
		if(rst>0)
		{
			System.out.println("Insertion success");
		}
	}
}