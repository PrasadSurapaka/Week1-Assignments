package com.day4.Dec8;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Override
public double getCosting() {
double salary = 0;
Iterator<Employee> employeeIterator = employees.iterator();

while(employeeIterator.hasNext()){
Employee employee = employeeIterator.next();
salary = salary + employee.getSalary();
}
return salary;
}

interface FifthAssignment {

 public void add(FifthAssignment employee) throws Exception;
 public void remove(FifthAssignment employee);
 public FifthAssignment getChild(int i);
 public String getName();
 public double getSalary();
 public String getDesignation();
 public void print();
}

class Director implements FifthAssignment {

	private String name;
	private double salary;

	public Director(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}

	List<FifthAssignment> employees = new ArrayList<FifthAssignment>();

	public void add(FifthAssignment obj) throws Exception {
		String c_name = obj.getClass().getName();
		if (c_name.equalsIgnoreCase("Manager")) {
			employees.add(obj);
		} else {
			throw new Exception("non Manager not allowed to add");
		}

	}

	public FifthAssignment getChild(int i) {
		return employees.get(i);
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	public String getDesignation() {
		return "Director";
	}

	public void print() {
		System.out.println("-------------");
		System.out.println("Name =" + getName());
		System.out.println("Salary =" + getSalary());
		System.out.println("-------------");

		Iterator<FifthAssignment> employeeIterator = employees.iterator();
		while (employeeIterator.hasNext()) {
			FifthAssignment employee = employeeIterator.next();
			employee.print();
		}
	}

	public void remove(FifthAssignment employee) {
		employees.remove(employee);
	}
}

class Manager implements FifthAssignment {

	private String name;
	private double salary;

	public Manager(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}

	List<FifthAssignment> employees = new ArrayList<FifthAssignment>();

	public void add(FifthAssignment employee) {
		employees.add(employee);
	}

	public FifthAssignment getChild(int i) {
		return employees.get(i);
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	public String getDesignation() {
		return "Manager";
	}

	public void print() {
		System.out.println("-------------");
		System.out.println("Name =" + getName());
		System.out.println("Salary =" + getSalary());
		System.out.println("-------------");

		Iterator<FifthAssignment> employeeIterator = employees.iterator();
		while (employeeIterator.hasNext()) {
			FifthAssignment employee = employeeIterator.next();
			employee.print();
		}
	}

	public void remove(FifthAssignment employee) {
		employees.remove(employee);
	}
}

class Developer implements FifthAssignment {

	private String name;
	private double salary;

	public Developer(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}

	public void add(FifthAssignment employee) {
		// this is leaf node so this method is not applicable to this class.
	}

	public FifthAssignment getChild(int i) {
		// this is leaf node so this method is not applicable to this class.
		return null;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	public String getDesignation() {
		return "Developer";
	}

	public void print() {
		System.out.println("-------------");
		System.out.println("Name =" + getName());
		System.out.println("Salary =" + getSalary());
		System.out.println("-------------");
	}

	public void remove(FifthAssignment employee) {
		// this is leaf node so this method is not applicable to this class.
	}

}

class CompositeEg {
	public static void main(String[] args) {
		try {
			FifthAssignment dir1 = new Director("dir1", 80000);
			FifthAssignment manager1 = new Manager("mgr1", 25000);

			FifthAssignment emp1 = new Developer("dev1", 10000);
			FifthAssignment emp2 = new Developer("dev2", 15000);

			manager1.add(emp1);
			manager1.add(emp2);

			dir1.add(manager1);

			FifthAssignment gManager = new Manager("mgr2", 50000);
			FifthAssignment emp3 = new Developer("dev3", 20000);

			gManager.add(emp3);
			gManager.add(manager1);

			dir1.add(gManager);
			dir1.print();

			dir1.add(new Developer("ldev", 19000));

			System.out.println("Designation: " + gManager.getDesignation());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}}
