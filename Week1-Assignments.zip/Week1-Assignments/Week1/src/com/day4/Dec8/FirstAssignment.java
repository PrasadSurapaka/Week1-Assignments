package com.day4.Dec8;

import java.sql.*;

public class FirstAssignment {
	public static void main(String[] args) throws Exception {

		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection ct = DriverManager.getConnection("jdbc:mysql://localhost:3306/tweet", "root", "12345");

		Statement st = ct.createStatement();

		ResultSet rs = st.executeQuery("select * from tweets");

		while (rs.next()) {
			int account_id = rs.getInt(1);
			String name = rs.getString(2);
			int balance = rs.getInt(3);

			System.out.println(account_id + "\t" + name + "\t" + balance);
		}
		rs.close();
		st.close();
		ct.close();

	}
}