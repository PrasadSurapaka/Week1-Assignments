package com.day4.Dec8;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SecondAssignment {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tweetdb", "root", "12345");
            
            PreparedStatement ps = con.prepareStatement("select * from tweet where tweet_text LIKE ");
            System.out.println("print the data");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){  
                System.out.println(rs.getInt(1)+" "+rs.getString(2));  
                }  
            rs.close();
            ps.close();
            
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}