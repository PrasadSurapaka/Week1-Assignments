package com.day3.Dec7;

import java.io.FileNotFoundException;

public class FirstAssignment {

	    public void demo() {
	        System.out.println("Inside method");
	        throw new  NullPointerException();
	    }

	    FirstAssignment(){
	        System.out.println("Inside constructor");
	        throw new ArithmeticException();
	    }

	 
	    public static void main(String[] args) {

	        try {
	            throw new FileNotFoundException();
	        } catch (Exception e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();        
	        }finally {
	            try {
	            throw new NumberFormatException();}catch (Exception e) {
	                // TODO: handle exception
	            }
	        }


	        FirstAssignment ref=new FirstAssignment();
	        ref.demo();

	    }
	}
