package com.day3.Dec7;

public class ThirdAssignment {
	static StringRevers stringRevers;
	public static void main(String[] args) {
		stringRevers = new StringRevers();
		stringRevers.start();
		stringRevers.setName("String Reverse");
		stringRevers.setString("Hello World");

		System.out.println("Child Thread is "+stringRevers);
		synchronized(stringRevers)
		{
			try{
				System.out.println("Main Thread : waiting ...");

				stringRevers.wait();
				//Thread.sleep(0,10);
				System.out.println("Main Thread : Completed ...");
			}catch(Exception e) {
				System.out.println("Interrupted Exception:"+e.getMessage());
				e.printStackTrace();
			}
			
		}
	}
}


class StringRevers extends Thread{
	String string;
	
	public void run(){
		
		try
		{
		synchronized(ThirdAssignment.stringRevers)
		{
			System.out.println("Child Thread running.... ");
			System.out.println("Original String "+string);
			StringBuilder sb = new StringBuilder();
			for(int i=string.length()-1;i>=0;i--)
			{
				sb.append(string.charAt(i));
				Thread.sleep(1000);
			}
			System.out.println("String in reverse "+sb.toString());
			System.out.println("Child Thread Completed!!!!");
			//after notify() parent Thread resumes execution
			ThirdAssignment.stringRevers.notify();
			System.out.println("notify() invoked from Child thread");
		}
		}catch(Exception et)
		{
			System.out.println(et);
		}
		
	}

	public String getString() {
		return string;
	}

	public void setString(String string) {
		this.string = string;
	}
	
}
