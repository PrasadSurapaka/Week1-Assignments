package com.day3.Dec7.Mainapp;

import com.day3.Dec7.InvalidDataException.InvalidDataException;
import com.day3.Dec7.StockLogic.StockLogic;

public class MainApp {
    public static void main(String[] args) {
        try{
            StockLogic slobj = new StockLogic();
            slobj.compute_avg("abcd.xls");
        }catch(InvalidDataException ide){
            System.out.println(ide.getMessage());
        }
    }
}
