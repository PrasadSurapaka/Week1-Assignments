package com.day3.Dec7.StockLogic;

import com.day3.Dec7.InvalidDataException.InvalidDataException;

public class StockLogic {
    public void compute_avg(String file_name) throws InvalidDataException{
        //read data from Excel
        if(true){
            throw new InvalidDataException("stock price invalid");
        }
    }
}