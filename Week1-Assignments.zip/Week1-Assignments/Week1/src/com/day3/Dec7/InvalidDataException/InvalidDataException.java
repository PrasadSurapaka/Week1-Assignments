package com.day3.Dec7.InvalidDataException;

public class InvalidDataException extends Exception{
    public InvalidDataException(String msg){
        super(msg);
        System.out.println("InvalidDataException:"+msg);
    }
}