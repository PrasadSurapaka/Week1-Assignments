package com.day5.Dec9;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ThirdAssignment {

	public static void main(String[] args) {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("C:\\Training\\regex\\RegxTestingFile.txt"));
			String data = br.readLine();
			while(data != null) {
				Pattern pt = Pattern.compile("[a-zA-Z0-9][a-zA-Z0-9_.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
				Matcher mt = pt.matcher(data);
				while (mt.find()) {
					System.out.println(mt.group());
				}
				data = br.readLine();
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}

}