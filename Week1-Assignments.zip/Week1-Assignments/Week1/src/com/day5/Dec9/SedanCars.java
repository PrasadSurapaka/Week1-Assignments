package com.day5.Dec9;

public class SedanCars extends Car {
 
    SedanCars() {
        super(CarTypes.SEDAN);
        construct();
    }
 
    @Override
    protected void construct() {
        System.out.println("Building sedan car");
        // add accessories
    }
}
