package com.day5.Dec9;

public class CarFactorys{
    public static Car buildCar(CarTypes model) {
        Car obj = null;
        switch (model) {
        case SMALL:
            obj = new SmallCars();
            break;
 
        case SEDAN:
            obj = new SedanCars();
            break;
 
        case LUXURY:
            obj = new LuxuryCars();
            break;
            
        case SPORTSCAR:
        	obj = new SportsCars();
        	break;
 
        default:
            // throw some exception
            break;
        }
        return obj;
    }
}