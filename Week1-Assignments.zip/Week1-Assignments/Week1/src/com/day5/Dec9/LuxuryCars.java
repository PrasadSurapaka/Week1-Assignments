package com.day5.Dec9;

public class LuxuryCars extends Car {

	LuxuryCars() {
		super(CarTypes.LUXURY);
		construct();
	}

	@Override
	protected void construct() {
		System.out.println("Building luxury car");
		// add accessories
	}
}
