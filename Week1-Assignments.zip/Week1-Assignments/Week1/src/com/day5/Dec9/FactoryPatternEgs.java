package com.day5.Dec9;

public class FactoryPatternEgs {
    public static void main(String[] args) {
    	
    	Car sObj = CarFactorys.buildCar(CarTypes.SMALL);
    	
    	Car snObj = CarFactorys.buildCar(CarTypes.SEDAN);
    	
    	Car lObj = CarFactorys.buildCar(CarTypes.LUXURY);
    	
    	Car spobj = CarFactorys.buildCar(CarTypes.SPORTSCAR);
    	
    	
    	//How to avoid printing of Class name along with hashcode
        System.out.println(sObj);
        
        System.out.println(snObj);
        
        System.out.println(lObj);
        
        System.out.println(spobj);
    }
}
