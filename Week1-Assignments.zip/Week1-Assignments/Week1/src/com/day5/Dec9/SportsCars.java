package com.day5.Dec9;

public class SportsCars extends Car {

	public SportsCars() {
		super(CarTypes.SPORTSCAR);
		
		construct();
		// TODO Auto-generated constructor stub
	}
	@Override
	protected void construct() {
		System.out.println("building SportsCar");
	
	}
}