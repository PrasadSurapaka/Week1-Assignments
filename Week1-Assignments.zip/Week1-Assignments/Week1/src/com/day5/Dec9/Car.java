package com.day5.Dec9;

public abstract class Car {
	 
    public Car(CarTypes model) {
        this.model = model;
        arrangeParts();
    }
 
    private void arrangeParts() {
        // Do one time processing here
    }
 
    // Do subclass level processing in this method
    protected abstract void construct();
 
    private CarTypes model = null;
 
    public CarTypes getModel() {
        return model;
    }
 
    public void setModel(CarTypes model) {
        this.model = model;
    }
}



























