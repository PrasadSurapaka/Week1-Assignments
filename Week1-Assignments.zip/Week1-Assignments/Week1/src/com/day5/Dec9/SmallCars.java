package com.day5.Dec9;

public class SmallCars extends Car {
 
    SmallCars() {
        super(CarTypes.SMALL);
        construct();
    }
 
    @Override
    protected void construct() {
        System.out.println("Building small car");
        // add accessories
    }
}
