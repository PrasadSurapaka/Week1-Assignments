package com.day5.Dec9;

public enum CarTypes {
    SMALL, SEDAN, LUXURY, SPORTSCAR
}
