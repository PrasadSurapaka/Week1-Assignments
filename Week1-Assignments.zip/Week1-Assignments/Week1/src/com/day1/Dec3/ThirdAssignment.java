package com.day1.Dec3;
class Demo {
	public void Display() throws Exception {
		System.out.println("Method1");
	}
}
public class ThirdAssignment extends Demo{
	@Override
	public void Display() {
		System.out.println("Method2");
	}

	public static void main(String[] args) {
		ThirdAssignment thirdAssignment = new ThirdAssignment();
		thirdAssignment.Display();
		

	}

}
