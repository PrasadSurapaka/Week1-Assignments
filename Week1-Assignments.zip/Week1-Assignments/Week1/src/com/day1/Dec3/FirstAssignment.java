package com.day1.Dec3;

class Singleton {
	
	private static Singleton single_instance = null;

	public String s;
    private static int count;

	private Singleton() {
		s = "Singleton class";
	}

	public static Singleton getInstance() {
		if (single_instance == null)
		{
			if(count<=3) {
				
			
			single_instance = new Singleton();
			Singleton.count++;
			}
		}
	

		return single_instance;
	}
}

public class FirstAssignment {

	public static void main(String args[]) {
		Singleton x = Singleton.getInstance();

		Singleton y = Singleton.getInstance();

		Singleton z = Singleton.getInstance();

		
	}
}