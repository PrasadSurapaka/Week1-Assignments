package com.day1.Dec3;
class Test{
	public static void Display() {
		System.out.println("Method1");
	}
	
}
public class SecondAssignment extends Test{
	@Override
	public static void Display() {
		System.out.println("Method2");
	}
	
	public static void main(String args[]) {
		
	}
}