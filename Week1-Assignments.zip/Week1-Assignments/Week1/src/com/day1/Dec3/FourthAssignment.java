package com.day1.Dec3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.TreeSet;

abstract class Employee{
	
	abstract void showEmp();
	
}


class PermanentEmployee extends Employee{
	
	private int salary;
	
	private String type;

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	void showEmp() {
		// TODO Auto-generated method stub
		System.out.println(salary + " " + type);
	}

	@Override
	public String toString() {
		return "PermanentEmployee [salary=" + salary + ", type=" + type + "]";
	}
	
	
	
}


class ContractEmployee extends Employee{

	private int salary;
	
	private String type;
	
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	void showEmp() {
		System.out.println(salary + " " + type);
		
	}

	@Override
	public String toString() {
		return "ContractEmployee [salary=" + salary + ", type=" + type + "]";
	}
	
	
}

public class FourthAssignment {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ContractEmployee cE = new ContractEmployee();
		cE.setSalary(8000);
		cE.setType("Contract");
		
		PermanentEmployee pE = new PermanentEmployee();
		pE.setSalary(10000);
		pE.setType("Permanent");
		
		ArrayList<Employee> emp = new ArrayList<Employee>();
		emp.add(cE);
		emp.add(pE);
		
		for(int i = 0;i<emp.size();i++)
		{
			System.out.println(emp.get(i));
		}
		
	}

}